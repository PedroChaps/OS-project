# Entrega da 1ª parte do projeto de SO

<br>


### Guia de instruções

* Para compilar os testes, fazer `make` na pasta principal;
* Para correr os testes, fazer `make test` para correr os testes todos ou `make test1`, `make test2`, `make test3` para correr os testes 1, 2, e 3, respetivamente;
* Para limpar os ficheiros binários criados, fazer `make clean`. 

<br>  

---
#### André Santo (al99179) e Pedro Chaparro (al99298)



